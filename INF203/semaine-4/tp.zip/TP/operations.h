#ifndef __OPERATIONS_H__
#define __OPERATIONS_H__
#include "joueurs.h"

int gain(joueurs *e) ;
int perte(joueurs *e) ;
int transfert(joueurs *e) ;

#endif
