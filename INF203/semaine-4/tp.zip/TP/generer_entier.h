#ifndef __GENERER_ENTIER_H__
#define __GENERER_ENTIER_H__

#include <stdlib.h>
#include <unistd.h>

// Genere un entier entre 0 et borne-1
long generer_entier(long borne);

#endif
